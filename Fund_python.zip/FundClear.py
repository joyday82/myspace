import time
import random
import pandas as pd
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from bs4 import BeautifulSoup
import openpyxl

chrome_options = Options()
chrome_options.add_argument("--start-maximized")  # 最大化窗口
chrome_options.add_argument("--disable-popup-blocking")
chrome_options.add_argument("user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36")

# 初始化 WebDriver
service = Service(ChromeDriverManager().install())
browser = webdriver.Chrome(service=service, options=chrome_options)

# 定義 Excel 欄位名稱
columns = ['序號', '基金級別名稱', '基金類型', '申購金額', '買回金額', '淨申贖金額', '國人持有金額', '級別規模', '最新淨值日期', '淨值', '交易量','持有規模']

# 用於存儲所有數據的列表
all_data = []


try:
     xpaths = [
        'A003600057',
        'B035100001',
        'A001800015',
        'A003100057',
        'B002900048',
        'A001100051',
        'A001800002',
        'A001100045',
        'A001100072',
        'A001100028'
    ]
    

     for xpath in xpaths:
     # 構建 URL，使用 f-string 或字符串格式化
        url = f'https://announce.fundclear.com.tw/MOPSFundWeb/INQ714.jsp?dataRange=1&fundCode={xpath}'
        print(url)
       
        browser.get(url)
        print('Page loaded')
        time.sleep(random.uniform(2, 5))
       
        # link = WebDriverWait(browser, 10).until(
            # EC.element_to_be_clickable((By.XPATH, 'https://announce.fundclear.com.tw/MOPSFundWeb/INQ714.jsp?dataRange=1&fundCode=','xpath'))
        # )
            # link.click()  # 點擊鏈接
        # print(f"Clicked link: {xpath}")
        # print(link.text)

        
        # time.sleep(random.uniform(2, 5)) 
    # 打開目標網址
    # url = 'https://announce.fundclear.com.tw/MOPSFundWeb/INQ714.jsp?dataRange=1&fundCode=A003600057'  # 替換為實際網址
    # browser.get(url)
    # print('Page loaded')
    # time.sleep(random.uniform(2, 5))
    # 等待第一個按鈕可點擊並點擊
        table = WebDriverWait(browser, 10).until(
                EC.presence_of_element_located((By.XPATH, '/html/body/table/tbody/tr[1]/td/form/table[2]'))
            )

        # 獲取所有行
        rows = table.find_elements(By.TAG_NAME, 'tr')
        for index, row in enumerate(rows):
        # 只處理從第三行開始的行（索引從 0 開始，所以第三行的索引是 2）
            if index >= 2:  # 這裡的 2 代表第三行
                # 獲取所有單元格
                cells = row.find_elements(By.TAG_NAME, 'td')
                cell_data = [cell.text for cell in cells]  # 獲取每個單元格的文本
                print(cell_data)  # 印每行的資料
                if cell_data:  # 確保 cell_data 不為空
                    all_data.append(cell_data)
       
        df = pd.DataFrame(all_data, columns=columns)

        # 將 DataFrame 寫入 Excel 文件
        output_file = 'fund_data.xlsx'
        df.to_excel(output_file, index=False)

        print(f'Data has been written to {output_file}')
except Exception as e:
    print(f"An error occurred: {e}")

finally:
    # 確保關閉瀏覽器
    browser.quit()