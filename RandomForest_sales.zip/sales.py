import pandas as pd
import matplotlib.pyplot as mp
import seaborn as sns
import datetime as dt
import sklearn.preprocessing as sp
import numpy as np
import sklearn.ensemble as se
import sklearn.model_selection as ms
import sklearn.metrics as sm
import mpltw

customer=pd.read_csv('/home/ubuntu/excel/project/Customer.csv')
prod_info = pd.read_csv('/home/ubuntu/excel/project/prod_cat_info.csv')
transaction = pd.read_csv('/home/ubuntu/excel/project/Transactions.csv')
# print(transaction['tran_date'].tail(10))
# print(transaction['tran_date'].min())
print(transaction.columns)
# 先將同樣意思的欄位名稱整理一致
prod_info.rename(columns={"prod_sub_cat_code":"prod_subcat_code"},inplace=True)

import datetime
from datetime import datetime
# 將transaction日期欄位進行處理
# for i in transaction['tran_date']:
#     if "/" in i:
#         i = i.replace("/", "-")
#         a = datetime.strptime(i,'%d-%m-%Y')
#         print(a)
#     else:
#         a=datetime.strptime(i,'%d-%m-%Y')
#         # print(i)
#     transaction['tran_date'].loc[i]=a

for i in transaction.loc[:,"tran_date"]:
    if "/" in i:
        transaction.loc[i,"tran_date"] = i.replace("/", "-")
        transaction.loc[i,"tran_date"]=datetime.strptime(transaction.loc[i,"tran_date"],"%d-%m-%Y")
        print(transaction.loc[i,"tran_date"])
    else:
        transaction.loc[i,"tran_date"]=datetime.strptime(i,"%d-%m-%Y")
        print(transaction.loc[i,"tran_date"])
pd.set_option('display.max_columns',None)
pd.set_option('display.max_rows',None)
print("內容是",transaction['tran_date'].tail(190))
print(transaction['tran_date'].min())


transaction['tran_date'] = pd.to_datetime(transaction['tran_date'], errors='coerce')
transaction.insert(loc=3, column='year', value= transaction.tran_date.dt.year)
transaction.insert(loc=4, column='month', value= transaction.tran_date.dt.month)
transaction.insert(loc=5, column='day', value=(transaction.tran_date.dt.weekday))
print(transaction.head(10))

# 合併transaction和prod_info成prod_concat
prod_concat = pd.merge(left=transaction, right=prod_info,on=["prod_cat_code","prod_subcat_code"],how="left")
print("prod_cocat:",prod_concat.columns)
print(prod_concat.isnull().sum())#找出每個Series的缺失值

# 再合併prod_concat和customer成finalfile
finalfile = pd.merge(left=prod_concat, right=customer,left_on="cust_id",right_on="customer_Id",how="left")
print(finalfile.columns)
print("是否有空值:",finalfile.isnull().sum())# 檢查資料是否有空值
# 找出Gender和city_code的眾數後填入空值
import statistics
print(statistics.mode(finalfile['Gender']))#M
print(statistics.mode(finalfile['city_code']))#4.0
# 將眾數取代空值
finalfile['Gender']=finalfile['Gender'].fillna('M')
finalfile['city_code']=finalfile['city_code'].fillna(4.0)
print("是否有空值:",finalfile.isnull().sum())# 檢查資料是否有空值
print(finalfile.dtypes)
print("資料是否重複:",finalfile.duplicated().sum())# 檢查資料是否有重複值
print(finalfile.shape)# 刪除重複值之前的行列
finalfile=finalfile.drop_duplicates()# 刪除重複值
print(finalfile.duplicated().sum())# 再次檢查資料是否有重複值
print(finalfile.shape)# 刪除重複值之後的行列
print("合併後的欄位",finalfile.columns)
# 三個標準差(std)之外可找出偏差值
print(finalfile.describe())
print(finalfile.columns)
print(finalfile.describe())

# 先進行資料統計和圖像化
# 分析哪些產品類別更受女性客戶和男性客戶歡迎？(可以看看要不要做假設檢定)
product_bygender = finalfile.groupby(["Gender","prod_cat"])[["Qty"]].sum().reset_index()
print(product_bygender)
# 先將Qty的正負數分兩組
rdf = finalfile[finalfile['Qty'] <= -1]
sdf = finalfile[finalfile['Qty'] >= 0]
mp.figure(facecolor='lightgray')
mp.title('不同性別喜歡的商品統計',fontsize=18)

sns.countplot(x = 'prod_cat', hue = "Gender", data = sdf, palette= "inferno")
mp.xlabel("prod_cat")
mp.ylabel("Qty")

# 哪個城市代碼的客戶最多，來自該城市的客戶百分比是多少？
customer_city=finalfile[['city_code','customer_Id']]
# print(customer_city.head(10))
customer_city=finalfile.groupby(['city_code'])['customer_Id'].aggregate('count').reset_index().sort_values('customer_Id', ascending=False)
print(customer_city)
mp.figure(facecolor='lightgray')
mp.title('最多客人的城市',fontsize=18)
sns.despine(top=True, right=True, left=False, bottom=False,offset=None, trim=False)
sns.barplot(x='city_code',y='customer_Id',hue ='city_code',data=customer_city,order=customer_city['city_code'],palette= "inferno")#barplot沒查到有長條圖的柱子寬度設定
mp.xlabel("City Code")
mp.ylabel("Customer Count")
# for a,b in zip('city_code','customer_city'):
#     mp.text(a, b, '%s' % b, ha='center', va= 'bottom',fontsize=7)
num1=1.01
num2=0
num3=3
num4=0
# 調整圖例位置
mp.legend(bbox_to_anchor=(num1, num2), loc=num3, borderaxespad=num4)

# 哪種商店類銷售最多的產品？
category_customer = finalfile.loc[:,finalfile.dtypes=='object']
mp.figure(facecolor='lightgray')
mp.title('銷售最多產品的通路',fontsize=18)
blue_palette = sns.color_palette("Blues")
sns.countplot(finalfile['Store_type'],palette=blue_palette)
mp.xlabel('Store Type')
mp.ylabel('Count')
# for a,b in zip('Store_type','Qty'):
#     mp.text(a, b, b, ha='center', va= 'bottom',fontsize=7)

# 男/女性各偏好在哪個通路購買東西？
gender_group = round(finalfile.pivot_table(index = "Store_type",columns="Gender", values="Qty", aggfunc='sum'),2)
print("Store_type",gender_group)
# male_earning = gender_group.loc["M"]
# print(male_earning)
mp.figure(facecolor='lightgray')
mp.title('男性最喜歡在哪個通路購物？',fontsize=18)
sns.countplot(x=finalfile['Store_type'],data=finalfile,hue='Gender',palette="gist_rainbow")
mp.xlabel('Store Type')
mp.ylabel("Qty")

# 從旗艦店的“電子產品”和“服裝”類別中賺取的總金額是多少？
store_group = round(finalfile.pivot_table(index = "prod_cat",columns="Store_type", values="total_amt", aggfunc='sum'),2)
total_amount=store_group.loc[["Clothing","Electronics"],"Flagship store"]
print(total_amount)

# 哪個商品的退貨率最高?
category = rdf.groupby(by=['prod_cat'], as_index = False)['Qty'].count()
mp.figure(facecolor='lightgray')
mp.title('退貨率最高的商品',fontsize=18)
sns.set_style('whitegrid')
sns.barplot(x = "prod_cat", y = 'Qty', data = category,  palette= "inferno")
# for x,y in enumerate('Qty'):
#         g.text(x,y,'%s'%y,ha='center')
x=finalfile['prod_cat']
y=finalfile['Qty']
# print('x是：',x)
# print(y)
# for a,b in zip('prod_cat','Qty'):
#     mp.text(a, b, '%s' % b, ha='center', va= 'bottom',fontsize=7)
mp.xlabel('Product Category')
mp.ylabel('Returned Orders')

# 最多的銷售額來自哪個年齡層?
# （1）首先把birth轉化为標準時間格式
print(finalfile['tran_date'].tail(20))
print(finalfile['tran_date'].min())
finalfile['DOB'] = pd.to_datetime(finalfile['DOB'])
finalfile['tran_date'] = pd.to_datetime(finalfile['tran_date'])
print(finalfile['tran_date'].tail(20))
print(finalfile['tran_date'].min())
# （2）獲取當前时間的年份，减去birth的年份
finalfile['age']=finalfile.tran_date.dt.year-finalfile.DOB.dt.year #當前的年份
# 把年齡數據分割成離散的區間
finalfile['age_cat'] = pd.cut(finalfile['age'],bins=[10,20,30,40,50],labels=['11-20','21-30','31-40','41-50'],include_lowest=True)
print(finalfile.columns)
# 得出每個年齡層的各種商品消費金額是多少？
customer_cat = finalfile.groupby(['age_cat','prod_cat'])['total_amt'].sum()
print(customer_cat)

# 最高消費力的年齡層為？
age_total_amount=finalfile['total_amt'].groupby(finalfile['age_cat']).sum()
# print(age_total_amount)
result = age_total_amount.idxmax()
print("最大消費力的年齡層是：",result,"歲,總消費金額為：",round(max(age_total_amount),2))
total_amount=finalfile.loc[finalfile['age_cat']=='21-30']
# 列出所有21-30歲的消費明細
# print(total_amount)
mp.figure(facecolor='lightgray')
mp.title('各年齡層的消費力統計',fontsize=18)
sns.set_style('whitegrid')
sns.barplot(x=finalfile['age_cat'], y='total_amt',data=finalfile)
mp.xlabel('age group')
mp.ylabel('total amount')

# 預測銷售數量(退貨要納入)
# print(finalfile.columns)
# 新建一列是否退貨
# 用1表示發生退貨,0沒有退貨
finalfile["returned or not"]=finalfile['Qty'].map(lambda x:1 if x<0 else 0)
print(finalfile.head(15))
a=finalfile['returned or not']==1
b=finalfile.loc[a,:]
# print(b)

# 整理輸入集與輸出集
from sklearn.preprocessing import LabelEncoder
labelencoder = LabelEncoder()
finalfile=pd.DataFrame(finalfile)
finalfile['Store_type'] = labelencoder.fit_transform(finalfile['Store_type'])
finalfile['prod_cat'] = labelencoder.fit_transform(finalfile['prod_cat'])
finalfile['prod_subcat'] = labelencoder.fit_transform(finalfile['prod_subcat'])
finalfile['Gender'] = labelencoder.fit_transform(finalfile['Gender'])

pd.set_option('display.max_columns',None)
pd.set_option('display.max_rows',None)
print("相關係數：",finalfile.corr())

# 日期處理

# print(finalfile['tran_date'].tail(160))
# max_date = finalfile["tran _date"].max()
# min_date=finalfile["tran_date"].min()
# print(min_date)
# totaldays=max_date-min_date
# print(totaldays)
# finalfile["total_days"]=finalfile['tran_date']-min_date
# print(finalfile['total_days'].head(15))
# print(finalfile['total_days'].tail(15))
# print(finalfile.columns)

# 因要預測的是QTY數量,因此在建立模型前刪除與QTY相關性較小的欄位
finalfile = finalfile.drop(columns=['transaction_id', 'cust_id', 'tran_date', 'customer_Id','DOB', 'city_code'])
print(finalfile.columns)
# print(finalfile_drop)
finalfile_drop=np.array(finalfile)
header=np.array(finalfile_drop[0][3:])
x=np.array(finalfile_drop[1:])[:,3:]
y=np.array(finalfile_drop[1:])[:,2]
print(x.shape)
print(y.shape)

train_x, test_x, train_y, test_y = ms.train_test_split(x, y, test_size=0.25)
# print(y,train_y,test_y)
# # 查看模型fit所執行時間
# import time
# start=time.time()
# # 建立模型
# model=se.RandomForestClassifier(max_depth=18,n_estimators=430)
# print(train_x,train_y)
# model.fit(train_x,train_y)
# end=time.time()
# print("執行時間:%f秒"%(end-start))
# # 輸出模型的預測效果
# predict_y=model.predict(test_x)
# print("預測結果：",predict_y)
# print("實際結果：",test_y)
# # # 輸出分類報告看f1分數
# cp=sm.classification_report(test_y,predict_y)
# print(cp)

# mp.legend()
# mp.tight_layout()
# mp.show()
"""
# 找出隨機森林最佳參數
train_scores,test_scores=ms.validation_curve(model,train_x,train_y,'max_depth',np.arange(10,20,1),cv=5)
test_scores_mean = np.mean(test_scores, axis=1)
train_scores_mean = np.mean(train_scores, axis=1)
lw = 2

# 畫出驗證曲線結果圖 x代表n_estimators y=f1得分
mp.figure(facecolor='lightgray')
mp.grid(linestyle=':')
mp.title('驗證曲線50-650',fontsize=18)
mp.plot(np.arange(10,20,1),test_scores.mean(axis=1),'o-',
        color='dodgerblue',label='validation curve')
mp.semilogx(np.arange(10,20,1), train_scores_mean, label="Cross-validation score",
             color="navy", lw=lw)

train_scores,test_scores=ms.validation_curve(model,train_x,train_y,'n_estimators',np.arange(400,500,10),cv=5)
print(test_scores.mean(axis=1))

# 畫出驗證曲線結果圖 x代表n_estimators y=f1得分
mp.figure(facecolor='lightgray')
mp.grid(linestyle=':')
mp.title('驗證曲線400-500',fontsize=18)
mp.plot(np.arange(400,500,10),test_scores.mean(axis=1),'o-',
        color='dodgerblue',label='validation curve')
"""
mp.legend()
mp.tight_layout()
mp.show()